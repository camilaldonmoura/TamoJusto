package utils;

public class Constants {
	
	public static String PATH_CHROMEDRIVER = ("C:\\\\Users\\\\55819\\\\Desktop\\\\academia-seleniumwebdriver-base\\\\src\\\\test\\\\resources\\\\drivers\\\\chromedriver.exe");

}
